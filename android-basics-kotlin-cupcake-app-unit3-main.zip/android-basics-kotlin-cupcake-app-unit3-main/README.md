Cupcake app


This app contains an order flow for cupcakes with options for quantity, flavor, and pickup date.
The order details get displayed on an order summary screen and can be shared to another app to
send the order.

This app demonstrates multiple fragments in an activity, a shared ViewModel across fragments,
data binding, LiveData, and the Jetpack Navigation component.




<img width="960" alt="cup" src="https://user-images.githubusercontent.com/83489094/187129221-52e75232-c4d2-4c00-8982-720d7d0681ac.png">


https://user-images.githubusercontent.com/83489094/187129364-c8f5d2ce-bbb1-4ea9-8162-91ec11a49393.mp4

